import { Component, OnInit} from '@angular/core';
import { kaur4139} from './kaur4139';
import{PawanService} from './pawan.service';
import { FoodItems } from './foodItems';
import breakfast from '../assets/data/Breakfast.json';
import lunch from '../assets/data/Lunch.json';
import dinner from '../assets/data/Dinner.json';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  asstitle = 'kaur4139A4';
  pfData:kaur4139;
  breakData : FoodItems[] = breakfast.breakfast;
  lunchData: FoodItems[] = lunch.lunch; 
  dinnerData: FoodItems[]= dinner.dinner;
  ngOnInit(){
this.lpLoad();
  }
  constructor(private LService: PawanService){

  }
  lpLoad():void{
this.pfData = this.LService.kaur4139();

  }
}
