export interface FoodItems{
    food: string;
    calories: string;
    price:string;
}