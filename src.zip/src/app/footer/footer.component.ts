import { Component, OnInit ,Input} from '@angular/core';

import{kaur4139} from'../kaur4139';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  @Input() footerProfile : kaur4139;
  constructor() { }

  ngOnInit() {
  }

}
