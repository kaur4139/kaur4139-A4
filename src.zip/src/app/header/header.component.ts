import { Component, OnInit , Input } from '@angular/core';

import{kaur4139} from'../kaur4139';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
@Input() headerProfile : kaur4139;
  constructor() { }

  ngOnInit() {
    
  }

}
