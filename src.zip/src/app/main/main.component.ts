import { Component, OnInit , Input } from '@angular/core';

import {FoodItems} from '../foodItems'

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  @Input() breakItems:FoodItems;
  @Input() lunchItems:FoodItems;
  @Input() dinnerItems:FoodItems;
  constructor() { }

  ngOnInit() {
  }

}