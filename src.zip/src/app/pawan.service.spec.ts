import { TestBed } from '@angular/core/testing';

import { PawanService } from './pawan.service';

describe('PawanService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PawanService = TestBed.get(PawanService);
    expect(service).toBeTruthy();
  });
});
