import { Injectable } from '@angular/core';
import {kaur4139} from'./kaur4139';
import {PAKA} from '../assets/data/paka';
@Injectable({
  providedIn: 'root'
})
export class PawanService {

  constructor() { }
  kaur4139() : kaur4139{
    return PAKA;
  }
}

