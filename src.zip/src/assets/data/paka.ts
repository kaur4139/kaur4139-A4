import {kaur4139} from '../../app/kaur4139';
export const PAKA: kaur4139 = {
    s_no: '7094', name: 'Pawanpreet', loname: 'kaur4139',  campus: 'Davis', asstitle: 'kaur4139A4'
};